package tests;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pages.Loginpage;

public class LoginTests extends BaseTest {
	Loginpage lp;

	@BeforeTest
	public void init() {
		lp = new Loginpage(driver);
	}

	@Test
	public void login() {
		lp.insertUssername("admin@gmail.com");
		lp.insertPassword("admin123");
		lp.clickonloginbtn();
	}

}
