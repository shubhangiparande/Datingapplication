package tests;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pages.Homepage;
import pages.Loginpage;

public class HomeTest extends BaseTest {
	Loginpage lp;
	Homepage hp;

	public void initobjects() {
		lp = new Loginpage(driver);
		hp = new Homepage(driver);
	}

	@BeforeTest
	public void init() {
		initobjects();
	}

	@Test
	public void validatesearchbox() {
		hp.sendkeytosearch("seeker8@gmail.com");

	}
	
	@Test
	public void validatemsg() {
		System.out.println(hp.gettextfrommsg());
	}
}
