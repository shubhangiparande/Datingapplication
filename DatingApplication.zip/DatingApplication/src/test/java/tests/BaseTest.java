package tests;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;

import io.github.bonigarcia.wdm.WebDriverManager;

public class BaseTest {
	WebDriver driver;

	@BeforeClass
	public void initialize() {
		WebDriverManager.chromedriver().setup();

		// step-1
		driver = new ChromeDriver();

		// step-2
		driver.manage().window().maximize();

		// step-3
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

	}

	@AfterSuite
	public void teardown() throws InterruptedException {
		Thread.sleep(10);
		driver.close();
	}

}
