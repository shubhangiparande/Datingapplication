package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Homepage {
	WebDriver driver;

	public Homepage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//input[@type='search']")
	WebElement searchbar;
	
	@FindBy(xpath = "//div[@id='datatable_info']")
	WebElement resultmsg;
	
	public void sendkeytosearch(String search) {
		if (searchbar.isEnabled()) {
			searchbar.sendKeys(search);
		}
	}
	
	public String gettextfrommsg() {
		
		String msg=resultmsg.getText();
		
		return msg;
}
}
