package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Loginpage {
	WebDriver driver;

	public Loginpage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//input[@id='email']")
	WebElement username;

	@FindBy(xpath = "//input[@id='password']")
	WebElement password;

	@FindBy(xpath = "//button[text()='Log In']")
	WebElement loginbutn;

	public void insertUssername(String uname) {
		if (username.isEnabled()) {
			username.sendKeys(uname);
		}
	}

	public void insertPassword(String pass) {
		if (password.isEnabled()) {
			password.sendKeys(pass);
		}
	}

	public void clickonloginbtn() {
		if (loginbutn.isEnabled()) {
			loginbutn.click();
		}
	}

}
